clear all
close all

Tsim=10;

Mm=2;Bm=0.1; %mass model: double integrator
Kp=185;Kd=27.2; %PD position controller for stability

% To understand the tuning
% set G=tf(1,[Mm Bm 0])
% and design the PD controller
% with  convenient tool
% for instance rltool(G)
% C=tf([Kd,Kp],1)
% [Gm,Pm,Wgm,Wpm] = margin(C*G);
% and check that the phase margin is correct
% Here it has been tuned for Pm=65 deg.

% admittance control
%M=; % Mass
%B=; % Damping
%K=; % Stiffness

