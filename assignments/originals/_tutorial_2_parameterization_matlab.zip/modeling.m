%%%%%%%%%%%%%% INIT %%%%%%%%%%%%%%

close all
clear all
clc

rr=0.2; % robot_radius
rh=0.12; % head radius
l3=0.18; % link3 length
n_points=100;

% head centre position wrt to Fb reference system
xT=0.57;yT=0; zT=0.57;pT=[xT,yT,zT];

%%%%%%%%%%%%%% TRANSFORMATIONS %%%%%%%%%%%%%%

% b->0
s0=
Rb0= % rotation matrix
pb0= % translation in the head centre
Tb0= % transformation matrix
    
% joint 1

R01=  % rotation matrix
p01= % translation 
T01= % transformation matrix    
Tb1= 
    
% joint 2
R12= % rotation matrix
p12=% translation 
T12= % transformation matrix    
Tb2=

% joint 3
R23=  % rotation matrix
p23= % translation 
T23=% transformation matrix    
Tb3=



%%%%%%%%%%%%%% PLOTS %%%%%%%%%%%%%%
 
hold on 
axis([0 xT+1.5*rr,yT-1.5*rr,yT+1.5*rr,0,zT+2*rr])
xlabel('x');ylabel('y');zlabel('z')

line([0,xT],[0 yT],[0,zT],'LineWidth',2,'LineStyle','--','Color','k')

plot3(xT,yT,zT,'bo','MarkerSize',5, 'MarkerFaceColor','r')
plot3(xT-rr*Tb1(1,3),yT-rr*Tb1(2,3),zT-rr*Tb1(3,3),'co','MarkerSize',12, 'MarkerFaceColor','k')
plot3(xT-rr*Tb2(1,3),yT-rr*Tb2(2,3),zT-rr*Tb2(3,3),'co','MarkerSize',12, 'MarkerFaceColor','k')
plot3(xT-rr*Tb3(1,3),yT-rr*Tb3(2,3),zT-rr*Tb3(3,3),'co','MarkerSize',12, 'MarkerFaceColor','k') 
plot3(xT-rr*Tb3(1,3),yT-rr*Tb3(2,3),zT-rr*Tb3(3,3),'bo','MarkerSize',15)

circular_arc(pT,rr,0,s1,Tb1,'r-')
circular_arc(pT,rr,0,s2,Tb2,'y-')
line([xT+(q3-l3)*Tb3(1,3) xT+(q3)*Tb3(1,3)], ...
    [yT+(q3-l3)*Tb3(2,3) yT+(q3)*Tb3(2,3)], ...
    [zT+(q3-l3)*Tb3(3,3) zT+(q3)*Tb3(3,3)],...
    'Color',[0.6 0.6 0.6],'LineStyle','-','LineWidth',5)



colormap([1, 0.75, 0.79])
[x,y,z]=sphere;

surf(xT+rh*x,rh*y,zT+rh*z)

alpha(0.4)
shading interp


box on
grid on
view([0,-1,0]);
rotate3d on

